"use client"
import TryItNow from "@/components/try-it-now"

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <TryItNow />
    </div>
  )
}
